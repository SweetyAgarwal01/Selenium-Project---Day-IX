package com.ibm.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UserPage 
{
	@FindBy(xpath="(//*[text()='SignUp'])[1]")
	WebElement signUpEle;
	
	@FindBy(xpath=("//input[@id='name']"))
	WebElement enterName;
	
	@FindBy(xpath=("//input[@id='pnum']"))
	WebElement enterPhoneNum;
	
	@FindBy(xpath=("//input[@id='password']"))
	WebElement enterPassword;
	
	@FindBy(xpath=("//input[@id='cpassword']"))
	WebElement enterConfirmPassword;
	
	@FindBy(xpath=("//input[@id='tccheckbox']"))
	WebElement enterTickbox;
	
	@FindBy(xpath=("//button[@id='mem_signup']"))
	WebElement SingUpbutn;
	
	@FindBy(xpath=("document.getElementById('my-account-id')"))
	WebElement MyaccountEle;
	@FindBy(xpath=("//*[text()='Log Out']"))
	WebElement signOutBtn;

	
	WebDriverWait wait;
	WebDriver driver;
	
	public UserPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(wait, this);
		this.driver=driver;
		this.wait=wait;
		}

	public void clickonSignUpButn()
	{
		signUpEle.click();
	}

	
	public void enterUserName(String User1)
	{
		enterName.sendKeys(User1);
	}
	
	public void enterUserPhoneNumber(String phonenumb)
	{
		enterPhoneNum.sendKeys(phonenumb);
	}
	
	public void enterUserpassword(String Userpassword)
	{
		enterPassword.sendKeys(Userpassword);
	}
	
	public void enterUserConfirmPass(String ConfirmPassword)
	{
		enterConfirmPassword.sendKeys(ConfirmPassword);
	}
	
	public void clickOnTickBtn()
	{
		enterTickbox.click();
	}

	public void clickOnUserSignUpButton()
	{
		SingUpbutn.click();
	}
	public void clickOnUserMyAccount()
	{
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("arguments[0].click();",MyaccountEle );
     }
	public void clickOnUserSignOutButton()
	{
		signOutBtn.click();
	}
	
	public void clickOnPromptbox()
	{
	wait.until(ExpectedConditions.alertIsPresent());
	Alert alertBox = driver.switchTo().alert();
	String text = alertBox.getText();
	System.out.println(text);
	alertBox.accept();
      }
	}