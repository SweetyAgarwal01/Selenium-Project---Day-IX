package com.ibm.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class AdminPage

{
	
	@FindBy(xpath="//*[@id='side-menu']/li[2]/a")
	WebElement catalogeEle;
	@FindBy(xpath="//*[@id='side-menu']/li[2]/ul/li[4]/a")
	WebElement productEle;
	@FindBy(xpath="//*[@title='Add New']")
	WebElement productaddEle;
	
	@FindBy(xpath="//*[@id='page-wrapper']/div/form/div[2]/div/div/div[2]/div/div/ul/li[2]/a")
	WebElement dataaddEle;
	
	@FindBy(xpath="//*[@id='page-wrapper']/div/form/div[2]/div/div/div[2]/div/div/ul/li[3]/a")
	WebElement linkaddEle;

	@FindBy(xpath="//*[@id='page-wrapper']/div/form/div[2]/div/div/div[2]/div/div/ul/li[4]/a")
	WebElement imageaddEle;
	
	@FindBy(xpath="//button[@title='Save']")
	WebElement savebtnEle;
	
	@FindBy(xpath="//*[text()='  Customers']")
	WebElement customerEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[5]/a/span")
	WebElement marketingEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[5]/ul/li[2]/a/i")
	WebElement mailEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/a")
	WebElement systemEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/ul/li[3]/a")
	WebElement shippingEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/ul/li[2]/a")
	WebElement userEle;
	
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/ul/li[5]/a")
	WebElement weightclassEle;
	
	@FindBy(xpath="//*[@id='side-menu']/li[6]/ul/li[1]/a")
	WebElement settingsEle;
	
	WebDriverWait wait;
	WebDriver driver;
	
	public AdminPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(wait, this);
		this.driver=driver;
		this.wait=wait;
		PageFactory.initElements(driver, this);
	}
	
	public void clickonMarketingtab()
	{
		marketingEle.click();
	}
	
	public void clickonMailtab()
	{
		mailEle.click();
	}
	
	public void clickonSystemtab()
	{
		systemEle.click();
	}
	
	public void clickonWeightClasstab()
	{
		weightclassEle.click();
	}

	public void clickonsettingstab()
	{
		settingsEle.click();
	}
	
	public void clickonshippingstab()
	{
		shippingEle.click();
	}
	
	public void clickonUsertab()
	{
		userEle.click();
	}
	public void clickonCustomerab()
	{
		customerEle.click();
	}

	public void clickonCatalogetab()
	{
		catalogeEle.click();
	}
	public void clickonProductTab()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='side-menu']/li[2]/ul/li[4]/a")));
		productEle.click();
	}
	
	public void clickonProductAddNew()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@title='Add New']")));
		productaddEle.click();
	}
	public void clickonDataAddNew()
	{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",dataaddEle ); 
	}
	public void clickonLinkAddNew()
	{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",linkaddEle ); 
	}
	public void clickonImageAddNew()
	{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",imageaddEle ); 
	}
	public void clickonSaveButton()
	{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",savebtnEle ); 
	}
}
	